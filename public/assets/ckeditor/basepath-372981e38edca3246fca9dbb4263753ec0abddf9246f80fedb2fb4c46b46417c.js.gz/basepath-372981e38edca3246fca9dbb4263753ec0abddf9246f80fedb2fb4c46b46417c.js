

var CKEDITOR_BASEPATH = "/assets/ckeditor/";
