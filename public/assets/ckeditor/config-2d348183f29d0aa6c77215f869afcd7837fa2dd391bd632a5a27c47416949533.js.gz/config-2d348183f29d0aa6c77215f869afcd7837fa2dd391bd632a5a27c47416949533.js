(function() {
  CKEDITOR.editorConfig = function(config) {
    config.enterMode = CKEDITOR.ENTER_BR;
    config.autoParagraph = false;
  };

}).call(this);
