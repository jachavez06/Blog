CKEDITOR.editorConfig = function (config) {
    config.extraPlugins = 'codemirror';

}
;
